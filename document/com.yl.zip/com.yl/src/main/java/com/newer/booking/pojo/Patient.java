package com.newer.booking.pojo;


import lombok.Data;

@Data
public class Patient {
    private String id;
    private String name;
    //private String id_card;
    private String phone;
    private String state;

}
