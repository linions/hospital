//package com.newer.booking;
//
//
//import com.newer.booking.mapper.DepartmentMapper;
//import com.newer.booking.pojo.Department;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.List;
//
//@SpringBootTest
//public class DepartmentTest {
//    @Autowired
//    private DepartmentMapper departmentMapper;
//
//    @Test
//    public void findAll(){
////        List<Department> list=departmentMapper.findAll();
////        for (Department department : list){
////            System.out.println(department.toString());
////        }
//    }
//}
