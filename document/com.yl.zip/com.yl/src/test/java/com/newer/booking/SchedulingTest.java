//package com.newer.booking;
//
//
//import com.newer.booking.mapper.SchedulingMapper;
//import com.newer.booking.pojo.Scheduling;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.HashMap;
//import java.util.List;
//
//@SpringBootTest
//public class SchedulingTest {
//    @Autowired
//    private SchedulingMapper schedulingMapper;
//    @Test
//    public void find(){
//        List<HashMap<String,Object>> scheduling=schedulingMapper.find(5);
//        for(HashMap<String,Object> scheduling1:scheduling){
//            System.out.println(scheduling1);
//        }
//    }
//
//}
