//package com.newer.booking;
//
//
//import com.newer.booking.mapper.ClinicMapper;
//import com.newer.booking.pojo.Clinic;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.List;
//
//@SpringBootTest
//public class ClinicTest {
//    @Autowired
//    private ClinicMapper clinicMapper;
//
//    @Test
//    public void findAll(){
//        List<Clinic> clinics=clinicMapper.findAll();
//        for(Clinic clinic:clinics){
//            System.out.println(clinic);
//        }
//    }
//}
