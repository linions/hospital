//package com.newer.booking;
//
//
//import com.newer.booking.mapper.DepartmentMapper;
//import com.newer.booking.mapper.DoctorMapper;
//import com.newer.booking.pojo.Doctor;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import java.util.List;
//
//@SpringBootTest
//public class DoctorTest {
//    @Autowired
//    private DoctorMapper doctorMapper;
//
//    @Test
//    public void findAll(){
////        List<Doctor> doctors=doctorMapper.findAll();
////        for(Doctor doctor:doctors){
////            System.out.println(doctor);
////        }
////    }
//
//}
